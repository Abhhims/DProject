import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Box,
  Typography,
  Link,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import PhoneIcon from "@mui/icons-material/Phone";
import ArrowForwardIosIcon from '@mui/icons-material/East';
import FacebookIcon from "@mui/icons-material/Facebook";
import InstagramIcon from "@mui/icons-material/Instagram";
import YouTubeIcon from "@mui/icons-material/YouTube";
import CloseIcon from "@mui/icons-material/Close";
import logo from "./logo.png"
const Header = () => {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const toggleDrawer = () => {
    setDrawerOpen(!drawerOpen);
  };

  return (
    <>
      {/* AppBar */}
      <AppBar position="sticky" elevation={3} sx={{top:'0', backgroundColor: "#fff",borderRadius:{xs:'0',md:'50px',lg:'50px'} ,padding:{xs:'12px 5px 12px 5px',md:'12px 50px 12px 10px',lg:'12px 50px 12px 10px'},maxWidth:'1440px',boxSizing:'border-box',margin:{xs:'0px',lg:'0 40px'},width:'auto'}}>
        <Toolbar sx={{ justifyContent: "space-between", alignItems: "center" }}>
          {/* Logo */}
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <img
              src={logo}
              alt="Hita Ayu Logo"
              style={{ maxWidth: "50px", marginRight: "10px" }}
            />
            <Typography
              variant="h6"
              sx={{ color: "#007bff", fontWeight: "bold",fontSize:{xs:'14px',md:'16px',lg:'18px'} }}
            >
              Hita.ayu Critical Care LLP
            </Typography>
          </Box>

          {/* Hamburger Menu for Mobile */}
          <IconButton
            edge="end"
            color="inherit"
            onClick={toggleDrawer}
            sx={{ display: { xs: "block", md: "none" }, color: "#007bff" }}
          >
            <MenuIcon />
          </IconButton>

          {/* Navigation Links (Hidden in Mobile) */}
          <Box sx={{ display: { xs: "none", md: "flex" }, gap: "20px" }}>
            <Link href="#Home" color="text.primary" underline="hover">
              Home
            </Link>
            <Link href="#About" color="text.primary" underline="hover">
              About Us
            </Link>
            <Link href="#Services" color="text.primary" underline="hover">
            Services
            </Link>
            <Link href="#Education" color="text.primary" underline="hover">
            Education
            </Link>
            <Link href="#Education" color="text.primary" underline="hover">
            Experience
            </Link>
            <Link href="#Activity" color="text.primary" underline="hover">
            Latest activity
            </Link>
            <Link href="#Contact" color="text.primary" underline="hover">
              Contact Us
            </Link>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Sidebar Drawer */}
      <Drawer
        anchor="left"
        open={drawerOpen}
        onClose={toggleDrawer}
        PaperProps={{
          sx: {
            width: "300px", // Sidebar width
            height: "auto", // Custom height
            maxHeight: "800px", // Set max height
            boxShadow: "0px 4px 8px rgba(0,0,0,0.2)",
          },
        }}
        sx={{ "& .MuiDrawer-paper": { width: "300px",padding:'15px' } ,}}
      >
        {/* Close Button */}
        <Box sx={{ display: "flex", alignItems: "center" }}>
            <img
              src={logo}
              alt="Hita Ayu Logo"
              style={{ width: "42px", marginRight: "10px" }}
            />
            <Typography
              sx={{ color: "#007bff", fontWeight: "bold",fontSize:{xs:'14px',md:'16px',lg:'18px'} }}
              >
              Hita.ayu Critical Care LLP
            </Typography>
          </Box>
        <Divider sx={{ my: 2 }} />

        {/* Drawer Links */}
        <List>
          {[   { text: "Home", link: "#Home" },
            { text: "About us", link: "#About" },
            { text: "Education", link: "#Education" },
            { text: "Experience", link: "#Education" },
            { text: "Services", link: "#Services" },
            { text: "Articles", link: "#Articles" },
            { text: "Contact Us", link: "#Contact" },
          ].map((item) => (
            <ListItem button onClick={()=>setDrawerOpen(false)} component="a" href={item.link} key={item.text}>
              <ListItemText  children={<Typography sx={{fontSize:{xs:'12px',md:'15px',lg:'16px'}}}>{item.text}</Typography>} />
              <ListItemIcon>
                <ArrowForwardIosIcon sx={{ color: "#007bff", fontSize: "16px" }} />
              </ListItemIcon>
            </ListItem>
          ))}
        </List>


        {/* Contact Section */}
        <Box sx={{ textAlign: "center", mt: 3 }}>
          <Link
            href="tel:+919867768221"
            sx={{
              display: "flex",
              justifyContent: "start",
              alignItems: "flex-start",
              textDecoration: "none",
              color: "#007bff",
              padding:'16px',
             fontSize:{xs:'14px',md:'16px',lg:'18px'},
            }}
          >
            <PhoneIcon sx={{ mr: 1, fontSize:'16px'}} /> +91 9867768221
          </Link>
        </Box>

        <Divider sx={{ my: 2 }} />
        {/* Social Media Icons */}
        <Box sx={{ display: "flex", justifyContent: "center",alignItems:'center', gap: 2, mb: 0 }}>
        <Typography
          variant="body2"
          sx={{ textAlign: "center", color: "gray" ,fontSize:{xs:'14px',md:'16px',lg:'18px'}}}
        >
          © Copyright © 2024
        </Typography> 
          <IconButton color="primary" href="#">
            <FacebookIcon />
          </IconButton>
          <IconButton color="primary" href="#">
            <InstagramIcon />
          </IconButton>
          <IconButton color="primary" href="#">
            <YouTubeIcon />
          </IconButton>
        </Box>

        {/* Footer */}
        
      </Drawer>
    </>
  );
};

export default Header;
