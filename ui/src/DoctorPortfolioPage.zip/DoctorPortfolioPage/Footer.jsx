import { Box, Stack, Typography } from '@mui/material'
import React from 'react'
import footerlogo from "./footerlogo.png"
import x from "./x.png"
import f from "./f.png"
import i from "./i.png"
import y from "./y.png"


const Footer = () => {
  return (
    <footer >
        <Box  sx={{display:'flex',alignItems:'center',justifyContent:'space-between',background:'black',padding:{xs:'20px 30px',md:'20px 80px',lg:'20px 100px'}}} >
<Stack  sx={{display:{xs:'none',md:'block',lg:'block'}}}><img src={footerlogo} style={{maxHeight:'80px',height:'auto'}} alt="logo" srcset="" /></Stack>
<Typography sx={{color:'white'}}>© Copyright 2024</Typography>
<Stack
direction={'row'}
spacing={2}>
  <a href="#Home"><img src={x} alt="" srcset="" /></a>
  <a href="#Home"><img src={f} alt="" srcset="" /></a>
  <a href="#Home"><img src={i} alt="" srcset="" /></a>
  <a href="#Home"><img src={y} alt="" srcset="" /></a>
</Stack>
        </Box>
    </footer>
  )
}

export default Footer